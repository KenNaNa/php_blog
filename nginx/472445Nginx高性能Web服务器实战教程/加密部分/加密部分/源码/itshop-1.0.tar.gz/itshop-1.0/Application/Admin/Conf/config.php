<?php
return array(
	//Session前缀
	'SESSION_PREFIX' => 'itcast_shop_admin',
	//自定义配置
	'USER_CONFIG' => array(
		'pagesize' => 5,  //每页显示的记录数
	)
);