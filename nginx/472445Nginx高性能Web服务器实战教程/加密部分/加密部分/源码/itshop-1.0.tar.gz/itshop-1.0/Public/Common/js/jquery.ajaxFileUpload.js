(function($){
	/*
	 * Ajax + FormData(HTML5)进度条文件上传
	 */
	$.fn.ajaxFileUpload = function(p){
		var thisObj = this; //容器
		var $button = thisObj.find("input[type=button]"); //上传按钮
		var $file = thisObj.find("input[type=file]");     //图片上传框
		var $img = thisObj.find("img");		  //图片回显框
		var $hidden = thisObj.find("input[type=hidden]"); //隐藏域
		var $progress = thisObj.find("p i");  //进度条
		var $per = thisObj.find("p b");		  //百分比
		//上传按钮单击事件
		$button.click(function(){
			//如果没有选择文件则不进行上传
			if($file.val()===""){
				alert("请先选择文件。");
				return false;
			}
			$(this).attr("disabled","disabled"); //禁用按钮
			var xhr = new XMLHttpRequest();
			xhr.upload.onprogress = function(e){
				var total = e.total; //数据总大小
				var loaded = e.loaded; //已经上传的大小
				var per = Math.floor(loaded/total*100); //计算百分比
				$progress.css("width",per + "%");
				$per.text(per + "%");
			};
			xhr.onreadystatechange = function(){
				if(xhr.readyState===4){
					$button.removeAttr("disabled"); //启用按钮
					if(xhr.status!==200){
						alert('上传失败');
					}else{
						//获得处理结果
						try{
							var json = JSON.parse(xhr.responseText);}
						catch(e){
							var json = {"ok":false,"msg":'上传失败：服务器异常'};
						};
						//判断是否成功
						if(json.ok){
							$hidden.attr("value",json.msg);
							thisObj.append($hidden);
							$img.attr("src", p.path+json.msg).show();
						}else{
							alert(json.msg);
						}
					}
				}
			};
			var fd = new FormData();
			fd.append(p.name, $file[0].files[0]);   //上传文件
			xhr.open("post", p.url);
			var getCookie = function(name){var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");if(arr=document.cookie.match(reg)) return unescape(arr[2]); else return null;};
			fd.append("PHPSESSID", getCookie("PHPSESSID"));
			xhr.send(fd);
		});
	};
})(jQuery);