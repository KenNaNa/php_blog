<?php

//获取当前是上传封面图还是编辑器里的图片
$func = (isset($_GET['editorid']) && $_GET['editorid']=='myEditor') ? 'uploadImage' : 'uploadThumb';

//Session验证
if(isset($_POST['PHPSESSID'])){
	session_id($_POST['PHPSESSID']);
}
session_start();
if(!isset($_SESSION['itcast_shop_admin']['userinfo'])){
	switch($func){
		case 'uploadImage':
			ajaxReturn(array('STATE'=>'请先登录。'));
		break;
		case 'uploadThumb':
			ajaxReturn(array('ok'=>false,'msg'=>'请先登录。'));
		break;
	}
}
$func();

//商品详情 商品封面图 上传
function uploadThumb(){
	//如果有图片上传，则上传并生成预览图
	$upfile = 'thumb'; //上传图片的name
	if(empty($_FILES[$upfile]) || $_FILES[$upfile]['error']!==0){
		ajaxReturn(array('ok'=>false,'msg'=>'错误：没有文件上传！'));
	}
	//准备上传目录
	$file = array('temp' => './Public/Uploads/temp/');              //准备临时目录
	file_exists($file['temp']) or mkdir($file['temp'],0777,true);   //自动创建临时目录
	//上传配置
	$config = array(
		'savePath' => $file['temp'],						 //存储文件夹
		'subPath' => '',									 //子目录
		'allowFiles' => array('.jpg','.jpeg','.png','.gif')  //允许的文件格式
	);
	//实例化UMEditor配套的文件上传类
	$Upload = new Uploader($upfile,$config);
	$info = $Upload->getFileInfo();
	if($info['state'] != 'SUCCESS'){
		ajaxReturn(array('ok'=>false,'msg'=>$info['state']));
	}
	//准备生成缩略图
	$file['name'] = $info['url'];		//文件名
	$file['save'] = date('Y-m/d');     //子目录
	$file['tempfile'] = $file['temp'].$file['name']; //临时文件的完整路径
	try{
		Image::thumb(Image::FILL,$file['tempfile'],350,300,array('base_path' => './Public/Uploads/big/','sub_path'=>$file['save'],'name'=>$file['name']));
		Image::thumb(Image::FILL,$file['tempfile'],220,220,array('base_path' => './Public/Uploads/small/','sub_path'=>$file['save'],'name'=>$file['name']));
	}catch(Exception $e){
		ajaxReturn(array('ok'=>false,'msg'=>$e->getMessage()));
	}
	unlink($file['tempfile']);        //删除临时文件
	//返回文件路径
	ajaxReturn(array('ok'=>true,'msg'=>$file['save'].$file['name']));
}


//商品详情 在线编辑器 图片上传
function uploadImage(){
	//上传目录
	$savePath = './Public/Uploads/desc';
	//上传配置
	$config = array(
		'savePath' => $savePath,     //存储文件夹
		'subPath' => date('Y-m/d'),  //子目录
		'allowFiles' => array('.gif','.png','.jpg','.jpeg','.bmp')  //允许的文件格式
	);
	//实例化UMEditor配套的文件上传类
	$Upload = new Uploader('upfile',$config);
	//返回JSON数据给UMEditor
	$callback = isset($_GET['callback']) ? $_GET['callback'] : false;
	$info = $Upload->getFileInfo();
	exit($callback ? "<script>$callback(".json_encode($info).')</script>' : json_encode($info));
}

function ajaxReturn($json){
	exit(json_encode($json));
}

/**
 * Created by JetBrains PhpStorm.
 * User: taoqili
 * Date: 12-7-18
 * Time: 上午11: 32
 * UEditor编辑器通用上传类
 */
class Uploader
{
    private $fileField;            //文件域名
    private $file;                 //文件上传对象
    private $config;               //配置信息
    private $oriName;              //原始文件名
    private $fileName;             //新文件名
    private $fullName;             //完整文件名,即从当前配置目录开始的URL
    private $fileSize;             //文件大小
    private $fileType;             //文件类型
    private $stateInfo;            //上传状态信息,
    private $stateMap = array(    //上传状态映射表，国际化用户需考虑此处数据的国际化
        "SUCCESS" ,                //上传成功标记，在UEditor中内不可改变，否则flash判断会出错
        "文件大小超出 upload_max_filesize 限制" ,
        "文件大小超出 MAX_FILE_SIZE 限制" ,
        "文件未被完整上传" ,
        "没有文件被上传" ,
        "上传文件为空" ,
        "POST" => "文件大小超出 post_max_size 限制" ,
        "SIZE" => "文件大小超出网站限制" ,
        "TYPE" => "不允许的文件类型" ,
        "DIR" => "目录创建失败" ,
        "IO" => "输入输出错误" ,
        "UNKNOWN" => "未知错误" ,
        "MOVE" => "文件保存时出错",
        "DIR_ERROR" => "创建目录失败"
    );

    /**
     * 构造函数
     * @param string $fileField 表单名称
     * @param array $config  配置项
     * @param bool $base64  是否解析base64编码，可省略。若开启，则$fileField代表的是base64编码的字符串表单名
     */
    public function __construct( $fileField , $config , $base64 = false )
    {
        $this->fileField = $fileField;
        $this->config = $config;
        $this->stateInfo = $this->stateMap[ 0 ];
        $this->upFile( $base64 );
    }

    /**
     * 上传文件的主处理方法
     * @param $base64
     * @return mixed
     */
    private function upFile( $base64 )
    {
        //处理base64上传
        if ( "base64" == $base64 ) {
            $content = $_POST[ $this->fileField ];
            $this->base64ToImage( $content );
            return;
        }

        //处理普通上传
        $file = $this->file = $_FILES[ $this->fileField ];
        if ( !$file ) {
            $this->stateInfo = $this->getStateInfo( 'POST' );
            return;
        }
        if ( $this->file[ 'error' ] ) {
            $this->stateInfo = $this->getStateInfo( $file[ 'error' ] );
            return;
        }
        if ( !is_uploaded_file( $file[ 'tmp_name' ] ) ) {
            $this->stateInfo = $this->getStateInfo( "UNKNOWN" );
            return;
        }

        $this->oriName = $file[ 'name' ];
        $this->fileSize = $file[ 'size' ];
        $this->fileType = $this->getFileExt();

        if ( !$this->checkSize() ) {
            $this->stateInfo = $this->getStateInfo( "SIZE" );
            return;
        }
        if ( !$this->checkType() ) {
            $this->stateInfo = $this->getStateInfo( "TYPE" );
            return;
        }

        $folder = $this->getFolder();

        if ( $folder === false ) {
            $this->stateInfo = $this->getStateInfo( "DIR_ERROR" );
            return;
        }

        $this->fullName = $folder . '/' . $this->getName();

        if ( $this->stateInfo == $this->stateMap[ 0 ] ) {
            if ( !move_uploaded_file( $file[ "tmp_name" ] , $this->fullName ) ) {
                $this->stateInfo = $this->getStateInfo( "MOVE" );
            }
        }
    }

    /**
     * 处理base64编码的图片上传
     * @param $base64Data
     * @return mixed
     */
    private function base64ToImage( $base64Data )
    {
        $img = base64_decode( $base64Data );
        $this->fileName = time() . rand( 1 , 10000 ) . ".png";
        $this->fullName = $this->getFolder() . '/' . $this->fileName;
        if ( !file_put_contents( $this->fullName , $img ) ) {
            $this->stateInfo = $this->getStateInfo( "IO" );
            return;
        }
        $this->oriName = "";
        $this->fileSize = strlen( $img );
        $this->fileType = ".png";
    }

    /**
     * 获取当前上传成功文件的各项信息
     * @return array
     */
    public function getFileInfo()
    {
        return array(
            "originalName" => $this->oriName ,
            "name" => $this->fileName ,
            "url" =>  $this->config['subPath'].'/'.$this->fileName,
            "size" => $this->fileSize ,
            "type" => $this->fileType ,
            "state" => $this->stateInfo
        );
    }

    /**
     * 上传错误检查
     * @param $errCode
     * @return string
     */
    private function getStateInfo( $errCode )
    {
        return !$this->stateMap[ $errCode ] ? $this->stateMap[ "UNKNOWN" ] : $this->stateMap[ $errCode ];
    }

    /**
     * 重命名文件
     * @return string
     */
    private function getName()
    {
        return $this->fileName = time() . rand( 1 , 10000 ) . $this->getFileExt();
    }

    /**
     * 文件类型检测
     * @return bool
     */
    private function checkType()
    {
        return in_array( $this->getFileExt() , $this->config[ "allowFiles" ] );
    }

    /**
     * 文件大小检测
     * @return bool
     */
    private function  checkSize()
    {
		if(empty($this->config[ "maxSize" ])){
			return true;
		}
		return $this->fileSize <= ( $this->config[ "maxSize" ] * 1024 );
    }

    /**
     * 获取文件扩展名
     * @return string
     */
    private function getFileExt()
    {
        return strtolower( strrchr( $this->file[ "name" ] , '.' ) );
    }

    /**
     * 按照日期自动创建存储文件夹
     * @return string
     */
    private function getFolder()
    {
        $pathStr = $this->config[ "savePath" ];
        if ( strrchr( $pathStr , "/" ) != "/" ) {
            $pathStr .= "/";
        }
        $pathStr .= $this->config[ "subPath" ];  //改进使之整合ThinkPHP
        if ( !file_exists( $pathStr ) ) {
            if ( !mkdir( $pathStr , 0777 , true ) ) {
                return false;
            }
        }
        return $pathStr;
    }
}
class Image{
	//定义常量，表示缩略图缩放类型
	const FILL = 0;			//等比例填充白色背景
	const SCALE = 1;		//等比例缩放
	const SCALE_FILL = 2;	//等比例缩放，最大缩放
	/**
	 * 为图片生成缩略图
	 * @param int $mode 缩略图生成模式
	 * @param string $file_path 原图路径
	 * @param int $new_width 目标宽度
	 * @param int $new_height 目标高度
	 * @param array $config 保存选项
	 * @return array [0]表示成功或失败，成功时[1]表示文件路径，失败时[1]表示错误信息
	 */
	public static function thumb($mode, $file_path, $new_width, $new_height, $config=[]){
		//获取原图的宽高，并判断文件类型
		$info = getimagesize($file_path);
		$width = $info[0];      //图片宽度
		$height = $info[1];     //图片高度
		$mime = $info['mime'];  //图片类型
		//关联图像 MIME 类型和文件扩展名
		$file_type = [
			'image/png' => '.png',
			'image/jpeg' => '.jpg'
		];
		//判断图像类型，只允许 JPG 和 PNG 两种类型
		if(!isset($file_type[$mime])){
			throw new Exception('图片创建缩略图失败：只支持 jpg 和 png 类型的图片。');
		}
		//生成缩略图
		$im = self::_create($mime, $file_path);
		switch($mode){
			case self::FILL:
				$im = self::_thumb_fill($im, $width, $height, $new_width, $new_height);
				break;
			case self::SCALE_FILL:
				$im = self::_thumb_scale($im, $width, $height, $new_width, $new_height, true);
				break;
			default: 
				$im = self::_thumb_scale($im, $width, $height, $new_width, $new_height);
		}
		//准备保存选项
		$config = array_merge([
			'base_path' => './',			//上传基本路径
			'sub_path' => date('Y-m/d/'),	//自动生成的子目录
			'name'=> md5(uniqid(rand())).$file_type[$mime] //自动创建文件名
		], $config);
		//自动创建目录
		$save_path = $config['base_path'].$config['sub_path'];
		if(!file_exists($save_path) && !mkdir($save_path, 0777, true)){
			throw new Exception('文件保存失败：创建目录失败');
		}
		//将保存缩略图到指定目录
		self::_save($mime, $im, $save_path.$config['name']);
		//返回文件路径（不包括base_path）
		return $config['sub_path'].$config['name'];
	}
	/**
	 * 生成缩略图（等比例填充白色背景）
	 * @param resource $im 原图资源
	 * @param int $width 原图宽度
	 * @param int $height 原图高度
	 * @param int $new_width 目标宽度
	 * @param int $new_height 目标高度
	 * @return 缩略图资源
	 */
	private static function _thumb_fill($im, $width, $height, $new_width, $new_height){
		//等比例缩放计算
		if($width/$new_width > $height/$new_height) {
			$dst_width = $new_width;
			$dst_height = round($new_width / $width * $height);
		}else{
			$dst_height = $new_height;
			$dst_width = round($new_height / $height * $width);
		}
		//创建缩略图资源
		$thumb = imagecreatetruecolor($new_width, $new_height);
		//填充白色背景
		imagefill($thumb, 0, 0, imagecolorallocate($thumb, 255, 255, 255));
		//计算缩略图在画布上的位置
		$dst_x = ($new_width - $dst_width) / 2;
		$dst_y = ($new_height - $dst_height) / 2;
		//将按比例将缩略图重新采样，调整其位置
		imagecopyresampled($thumb, $im, $dst_x, $dst_y, 0, 0, $dst_width, $dst_height, $width, $height);
		return $thumb;
	}
	/**
	 * 生成缩略图（等比例缩放）
	 * @param resource $im 原图资源
	 * @param int $width 原图宽度
	 * @param int $height 原图高度
	 * @param int $max_width 最大宽度
	 * @param int $max_height 最大高度
	 * @param bool $fill  是否最大缩放
	 * @return 缩略图资源
	 */
	private static function _thumb_scale($im, $width, $height, $max_width, $max_height, $fill=false){
		$dst_width = $width;
		$dst_height = $height;
		if($width/$max_width > $height/$max_height) {
			if($fill || ($width > $max_width)){
				$dst_width = $max_width;
				$dst_height = round($max_width / $width * $height);
			}
		}else{
			if($fill || ($height > $max_height)){
				$dst_height = $max_height;
				$dst_width = round($max_height / $height * $width);
			}
		}
		//创建缩略图资源
		$thumb = imagecreatetruecolor($dst_width, $dst_height);
		//将原图缩放填充到缩略图画布中
		imagecopyresampled($thumb, $im, 0, 0, 0, 0, $dst_width, $dst_height, $width, $height);
		return $thumb;
	}
	/**
	 * 根据原图文件创建图像资源
	 * @param string 图像MIME类型
	 * @param string 原图文件路径
	 * @return 返回创建的图像资源
	 */
	private static function _create($mime, $file_path){
		switch($mime){
			case 'image/png':  return imagecreatefrompng($file_path);
			case 'image/jpeg': return imagecreatefromjpeg($file_path);
		}
	}
	/**
	 * 保存图像资源
	 * @param string $mime 图像MIME类型
	 * @param resource $im 图像资源
	 * @param string $save_path 保存路径
	 * @return 成功返回true
	 */
	private static function _save($mime, $im, $save_path){
		switch($mime){
			case 'image/png':  return imagepng($im, $save_path);
			case 'image/jpeg': return imagejpeg($im, $save_path, 100);
		}
	}
}