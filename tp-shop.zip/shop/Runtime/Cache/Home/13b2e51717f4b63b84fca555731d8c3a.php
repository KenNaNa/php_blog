<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>
        </title>
    </head>
    <body>
        <h1><?php echo ($a); ?></h1>
        <form class="" action="<?php echo U('Home/User/ff','ids=2222');?>" method="post">
            <input type="text" name="id" value="">
            <input type="submit" name="" value="点我呀！！！">
        </form>


    </body>
</html>