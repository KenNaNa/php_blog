<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<div>
		<div id="left">			
			@section('left')
			aaa
			@show
		</div>
		<div id="right">
			@section('right')
			bbb
			@show
		</div>
   </div>
</body>
</html>