@extends('parent')

@section('left')
	圣诞节
	@parent
@endsection

@section('right')
	平安夜
	@parent
@endsection